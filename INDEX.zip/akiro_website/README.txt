AKIRO MULTI-PAGE WEBSITE DEMO

Pages:
- index.html       Home / overview
- about.html       About the concept
- platform.html    Platform capabilities
- solutions.html   Use cases and approach
- contact.html     Contact form demo
- admin-login.html Admin login
- admin.html       Admin dashboard demo

Run:
1. Extract the ZIP.
2. Open index.html in a browser.
3. For 3D globe visuals and Google Fonts, internet access is required.

Admin demo:
Email: admin@akiro.demo
Password: demo123

IMPORTANT:
This is a static front-end prototype. The admin login is only a demo gate using browser sessionStorage.
It is not secure and must not be used for real accounts. Dashboard data is illustrative.
The contact form does not transmit data. Connect a backend, database, secure authentication,
AI API and analytics provider before production use.
