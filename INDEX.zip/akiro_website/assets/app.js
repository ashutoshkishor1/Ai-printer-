
const $=s=>document.querySelector(s);
function toggleMenu(){$('.nav').classList.toggle('open')}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.style.display='block';setTimeout(()=>t.style.display='none',2800)}
function submitContact(e){e.preventDefault();toast('Message received in this demo. Connect a backend to deliver enquiries.');e.target.reset()}
function adminLogin(e){e.preventDefault();const email=$('#email').value,pass=$('#password').value;if(email==='admin@akiro.demo'&&pass==='demo123'){sessionStorage.setItem('akiroAdmin','yes');location.href='admin.html'}else toast('Demo credentials do not match.')}
function guardAdmin(){if(sessionStorage.getItem('akiroAdmin')!=='yes'){location.href='admin-login.html'}}
function logout(){sessionStorage.removeItem('akiroAdmin');location.href='index.html'}
function adminSection(id){document.querySelectorAll('[data-admin-section]').forEach(x=>x.style.display=x.dataset.adminSection===id?'block':'none');document.querySelectorAll('.admin-side a').forEach(x=>x.classList.toggle('active',x.dataset.target===id))}
document.addEventListener('DOMContentLoaded',()=>{
 const c=$('#year');if(c)c.textContent=new Date().getFullYear();
 const clock=$('#clock');if(clock){const tick=()=>clock.textContent=new Date().toLocaleTimeString();tick();setInterval(tick,1000)}
 const canvas=$('#hero-canvas');if(canvas&&window.THREE){try{const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(45,1,.1,100);camera.position.z=4;const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));const g=new THREE.Group();scene.add(g);const globe=new THREE.Mesh(new THREE.SphereGeometry(1.15,42,42),new THREE.MeshPhongMaterial({color:0x087eaa,wireframe:true,transparent:true,opacity:.55}));g.add(globe);const core=new THREE.Mesh(new THREE.SphereGeometry(1.04,32,32),new THREE.MeshBasicMaterial({color:0x0a6b92,transparent:true,opacity:.08}));g.add(core);const ring=new THREE.Mesh(new THREE.TorusGeometry(1.42,.008,8,120),new THREE.MeshBasicMaterial({color:0x67e8f9,transparent:true,opacity:.8}));ring.rotation.x=1.1;g.add(ring);const light=new THREE.PointLight(0x67e8f9,2,10);light.position.set(2,2,3);scene.add(light);scene.add(new THREE.AmbientLight(0x9defff,.8));function resize(){const w=canvas.clientWidth||400,h=canvas.clientHeight||400;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}addEventListener('resize',resize);resize();function loop(){requestAnimationFrame(loop);g.rotation.y+=.002;g.rotation.x=Math.sin(Date.now()*.0003)*.08;ring.rotation.z+=.003;renderer.render(scene,camera)}loop()}catch(err){canvas.style.display='none'}}
});
